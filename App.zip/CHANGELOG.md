# Changelog

## 8.1.0

-   Remastered from the ground up with a new design
-   Migrate CRA to NextJS
